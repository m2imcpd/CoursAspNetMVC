const {desktopCapturer, ipcRenderer, remote} = require('electron')
const domify = require('domify')

let localStream
let microAudioStream
let recordedChunks = []
let numRecordedChunks = 0
let recorder
let includeMic = false

document.addEventListener('DOMContentLoaded', () => {
  document.querySelector('#enregistrer').addEventListener('click', recordDesktop)
  document.querySelector('#micro-audio').addEventListener('click', microAudioCheck)
  document.querySelector('#arreter').addEventListener('click', stopRecording)
  document.querySelector('#tester').addEventListener('click', play)
  document.querySelector('#telecharger').addEventListener('click', download)
})



const disableButtons = () => {
  document.querySelector('#enregistrer').disabled = true
  document.querySelector('#arreter').hidden = false
  document.querySelector('#tester').hidden = true
  document.querySelector('#telecharger').hidden = true
}

const enableButtons = () => {
  document.querySelector('#enregistrer').disabled = false
  document.querySelector('#arreter').hidden = true
  document.querySelector('#tester').hidden = true
  document.querySelector('#telecharger').hidden = true
}

const microAudioCheck = () => {
  var video = document.querySelector('video')
  video.muted = true
  includeMic = !includeMic
  if (includeMic) {
    navigator.webkitGetUserMedia({ audio: true, video: false },
        getMicroAudio, getUserMediaError)
  }
}



const cleanRecord = () => {
  recordedChunks = []
  numRecordedChunks = 0
}

ipcRenderer.on('source-id-selected', (event, sourceId) => {
  if (!sourceId) return
  console.log(sourceId)
  onAccessApproved(sourceId)
})

const recordDesktop = () => {
  cleanRecord()
  ipcRenderer.send('show-picker', { types: ['screen'] })
}

const recordWindow = () => {
  cleanRecord()
  ipcRenderer.send('show-picker', { types: ['window'] })
}

const recorderOnDataAvailable = (event) => {
  if (event.data && event.data.size > 0) {
    recordedChunks.push(event.data)
    numRecordedChunks += event.data.byteLength
  }
}

const stopRecording = () => {
  enableButtons()
  document.querySelector('#tester').hidden = false
  document.querySelector('#telecharger').hidden = false
  recorder.stop()
  localStream.getVideoTracks()[0].stop()
}

const play = () => {
  let video = document.querySelector('video')
  video.muted = false
  let blob = new Blob(recordedChunks, {type: 'video/webm'})
  video.src = window.URL.createObjectURL(blob)
}

const download = () => {
  let blob = new Blob(recordedChunks, {type: 'video/webm'})
  let url = URL.createObjectURL(blob)
  let a = document.createElement('a')
  document.body.appendChild(a)
  a.style = 'display: none'
  a.href = url
  a.download = 'capture-video.webm'
  a.click()
  setTimeout(function () {
    document.body.removeChild(a)
    window.URL.revokeObjectURL(url)
  }, 100)
}

const getMediaStream = (stream) => {
  let video = document.querySelector('video')
  video.src = URL.createObjectURL(stream)
  localStream = stream
  stream.onended = () => { console.log('arreter video') }

  let videoTracks = localStream.getVideoTracks()

  if (includeMic) {
    let audioTracks = microAudioStream.getAudioTracks()
    localStream.addTrack(audioTracks[0])
  }
  try {
    console.log('démarrer enregistrement')
    recorder = new MediaRecorder(stream)
  } catch (e) {
    console.assert(false, 'error' + e)
    return
  }
  recorder.ondataavailable = recorderOnDataAvailable
  recorder.onstop = () => { console.log('arret enregistrement') }
  recorder.start()
  disableButtons()
}

const getMicroAudio = (stream) => {
  console.log('audio ok')
  microAudioStream = stream
  stream.onended = () => { console.log('audio fin') }
}

const getUserMediaError = () => {
  console.log('error')
}

const onAccessApproved = (id) => {
  if (!id) {
    console.log('error')
    return
  }
  navigator.webkitGetUserMedia({
    audio: false,
    video: { mandatory: { chromeMediaSource: 'desktop', chromeMediaSourceId: id,
      maxWidth: window.screen.width, maxHeight: window.screen.height } }
  }, getMediaStream, getUserMediaError)
}
